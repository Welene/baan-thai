import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { docClient } from '../../../services/clients.mjs';

const dynamodb = docClient;
const TABLE_NAME = process.env.TABLE_NAME;

export const handler = async (event) => {
	console.log('getAdminUsers invoked');

	// API_KEY START ----------------------------------------------
	const incomingKey = event.headers?.["x-api-key"];
	const expectedKey = process.env.API_KEY;

	if (incomingKey !== expectedKey) {
		return {
			statusCode: 401,
			headers: {
				'Content-Type': 'application/json',
				'Access-Control-Allow-Origin': '*',
				'Access-Control-Allow-Credentials': true,
			},
			body: JSON.stringify({ error: 'Invalid API Key' }),
		};
	}
	// API_KEY END ------------------------------------------------
	
	try {
		// Hämta role från query parameters (optional filter)
		const role = event.queryStringParameters?.role;
		
		// Bygg scan parameters
		const params = {
			TableName: TABLE_NAME,
			FilterExpression: 'begins_with(PK, :userPrefix) AND SK = :sk',
			ExpressionAttributeValues: {
				':userPrefix': 'USER#',
				':sk': 'PROFILE',
			},
		};
		
		// Om role finns, lägg till filter för det
		if (role) {
			params.FilterExpression += ' AND #role = :role';
			params.ExpressionAttributeNames = {
				'#role': 'role',
			};
			params.ExpressionAttributeValues[':role'] = role;
		}
		
		const result = await dynamodb.send(new ScanCommand(params));
		
		// Ta bort känslig data (passwordHash)
		const users = result.Items.map(user => ({
			userId: user.userId,
			email: user.email,
			name: user.name,
			username: user.username,
			role: user.role,
			address: user.address,
			phoneNumber: user.phoneNumber,
			createdAt: user.createdAt,
			updatedAt: user.updatedAt,
		}));
		
		return {
			statusCode: 200,
			body: JSON.stringify({
				users,
				count: users.length,
			}),
		};
	} catch (error) {
		console.error('Error fetching users:', error);
		return {
			statusCode: 500,
			body: JSON.stringify({
				error: 'Kunde inte hämta användare',
				details: error.message,
			}),
		};
	}
};

// Create: Sunsanee
// Helene edit: added fetchWithApiKey in every api call for extra api protection
