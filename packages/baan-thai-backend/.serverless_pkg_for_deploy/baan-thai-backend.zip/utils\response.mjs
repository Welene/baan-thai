import { sendResponse } from '../responses/response.mjs';

export { sendResponse };
